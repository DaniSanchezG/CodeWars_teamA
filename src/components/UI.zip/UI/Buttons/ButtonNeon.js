import classes from "./ButtonNeon.module.css";

function ButtonNeon() {
  return (
    <>
      <div className={classes["-container"]}>
        <span></span>
        <span></span>
      </div>
    </>
  );
}

export default ButtonNeon;
